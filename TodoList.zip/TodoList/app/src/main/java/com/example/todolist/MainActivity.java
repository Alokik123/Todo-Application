package com.example.todolist;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements TodoAdapter.ItemClickListener {

    private ArrayList<String> todoList;
    private TodoAdapter todoAdapter;
    private RecyclerView recyclerView;
    private EditText etNewItem;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etNewItem = findViewById(R.id.etNewItem);
        recyclerView = findViewById(R.id.recyclerView);

        todoList = new ArrayList<>();
        todoAdapter = new TodoAdapter(todoList, this);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(todoAdapter);

        todoList.add("Learn Android");
        todoList.add("Build an App");
        todoAdapter.notifyDataSetChanged();
    }

    public void onAddItem(View view) {
        String newItem = etNewItem.getText().toString().trim();
        if (!newItem.isEmpty()) {
            todoList.add(newItem);
            todoAdapter.notifyDataSetChanged();
            etNewItem.setText("");
        }
    }

    @Override
    public void onItemLongClick(int position) {
        showDeleteDialog(position);
    }

    @Override
    public void onItemClick(int position) {
        showEditDialog(position);
    }

    private void showDeleteDialog(final int position) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Item")
                .setMessage("Are you sure you want to delete this item?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    todoList.remove(position);
                    todoAdapter.notifyDataSetChanged();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showEditDialog(final int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Item");

        final EditText input = new EditText(this);
        input.setText(todoList.get(position));
        builder.setView(input);

        builder.setPositiveButton("Save", (dialog, which) -> {
            String editedText = input.getText().toString().trim();
            if (!editedText.isEmpty()) {
                todoList.set(position, editedText);
                todoAdapter.notifyDataSetChanged();
            }
        });

        builder.setNegativeButton("Cancel", null);

        builder.show();
    }
}
